import random
import matplotlib.pyplot as plt; plt.rcdefaults()
import numpy as np
import matplotlib.pyplot as plt
from tkinter import *
from PIL import ImageTk, Image

root = Tk()
root.title("Rock Paper Scissors")
root.geometry("500x500")

# global variables to keep track of the score
WINS = 0
LOSSES = 0
TIES = 0

# variables to keep track of streaks
WIN_STREAK = 0
LOSE_STREAK = 0
TIE_STREAK = 0

USER=""
CPU=""

text_box4=""

#images
starting = ImageTk.PhotoImage(Image.open("images/starting.gif"))
fivewins = ImageTk.PhotoImage(Image.open("images/fivewins1.gif"))
winstreak = ImageTk.PhotoImage(Image.open("images/winstreak1.gif"))
losestreak = ImageTk.PhotoImage(Image.open("images/losestreak1.gif"))
tiestreak = ImageTk.PhotoImage(Image.open("images/tiestreak1.gif"))
loseten = ImageTk.PhotoImage(Image.open("images/loseten.gif"))
special_number = ImageTk.PhotoImage(Image.open("images/69.gif"))

image_list = [starting, fivewins, winstreak, losestreak, tiestreak, loseten, special_number]

#starting image that user will see when program first opens up
my_image = Label(image=starting)
my_image.grid(row=0, pady = 50)

#define rock (1)
def rock():
    global USER
    global CPU
    USER = "ROCK"
    CPU = cpu_move()
    result(USER, CPU)

#define paper (2)
def paper():
    global USER
    global CPU
    USER = "PAPER"
    CPU = cpu_move()
    result(USER, CPU)

#define scissor (3)
def scissor():
    global USER
    global CPU
    USER = "SCISSOR"
    CPU = cpu_move()
    result(USER, CPU)

# Displays a bar chart to show how the user is doing
def stats():
    objects = ('Wins', 'Losses', 'Ties')
    y_pos = np.arange(len(objects))
    score = [WINS, LOSSES, TIES]

    plt.bar(y_pos, score, align='center', alpha=0.5)
    plt.xticks(y_pos, objects)
    plt.ylabel('#')
    plt.title('Game Results')

    plt.show()

# randint to determine CPU move
def cpu_move():
    global CPU
    random_num = random.randint(1, 3)
    if random_num == 1: #rock
        CPU = "ROCK"
        return CPU
    elif random_num == 2: #paper
        CPU = "PAPER"
        return CPU
    elif random_num == 3: #scissor
        CPU = "SCISSOR"
        return CPU


def result(USER, CPU):
    global WINS
    global LOSSES
    global TIES
    global WIN_STREAK
    global LOSE_STREAK
    global TIE_STREAK
    global text_box4
    global my_image

    #all possible rock paper scissor situations
    if USER == CPU:
        text_box3 = "It's a tie!"
        TIES += 1
        TIE_STREAK += 1
        WIN_STREAK = 0
        LOSE_STREAK = 0
    if USER == "ROCK" and CPU == "SCISSOR":
        text_box3 = "You win!"
        WINS += 1
        WIN_STREAK += 1
        LOSE_STREAK = 0
        TIE_STREAK = 0
    if USER == "ROCK" and CPU == "PAPER":
        text_box3 = "You lose!"
        LOSSES += 1
        LOSE_STREAK += 1
        WIN_STREAK = 0
        TIE_STREAK = 0
    if USER == "PAPER" and CPU == "ROCK":
        text_box3 = "You win!"
        WINS += 1
        WIN_STREAK += 1
        LOSE_STREAK = 0
        TIE_STREAK = 0
    if USER == "PAPER" and CPU == "SCISSOR":
        text_box3 = "You lose!"
        LOSSES += 1
        LOSE_STREAK += 1
        WIN_STREAK = 0
        TIE_STREAK = 0
    if USER == "SCISSOR" and CPU == "PAPER":
        text_box3 = "You win!"
        WINS += 1
        WIN_STREAK += 1
        LOSE_STREAK = 0
        TIE_STREAK = 0
    if USER == "SCISSOR" and CPU == "ROCK":
        text_box3 = "You lose!"
        LOSSES += 1
        LOSE_STREAK += 1
        WIN_STREAK = 0
        TIE_STREAK = 0

    #for special occasions
    if WINS == 69 or LOSSES == 69 or TIES == 69:
        text_box4 = ":^)"
        my_image.grid_forget()
        my_image = Label(image=special_number)
        my_image.grid(row=0, pady=50)
    elif LOSE_STREAK % 10 == 0 and LOSE_STREAK > 1:
        text_box4 = "...Wow."
        my_image.grid_forget()
        my_image = Label(image= loseten)
        my_image.grid(row=0, pady=50)
    elif WINS % 5 == 0 and WINS > 1:
        text_box4 = "You're doing great! Keep it up!"
        my_image.grid_forget()
        my_image = Label(image = fivewins)
        my_image.grid(row=0, pady=50)
    elif WIN_STREAK % 3 == 0 and WIN_STREAK > 1:
        text_box4 = "You're on fire!"
        my_image.grid_forget()
        my_image = Label(image=winstreak)
        my_image.grid(row=0, pady=50)
    elif LOSE_STREAK % 3 == 0 and LOSE_STREAK > 1:
        text_box4 = "Getcha head in the game!"
        my_image.grid_forget()
        my_image = Label(image=losestreak)
        my_image.grid(row=0, pady=50)
    elif TIE_STREAK % 3 == 0 and TIE_STREAK > 1:
        text_box4 = "This is pretty exciting!"
        my_image.grid_forget()
        my_image = Label(image=tiestreak)
        my_image.grid(row=0, pady=50)

    #text box to display score
    msg_box1=Text(root, height = 1, width=30, state = NORMAL)
    msg_box1.grid(row=5)
    text_box1 = "WINS:" + str(WINS) + " LOSSES:" + str(LOSSES) + " TIES:" + str(TIES)
    msg_box1.insert(END, text_box1)

    #text box to show user's move and cpu's move
    msg_box2 = Text(root, height=2, width=30, state=NORMAL)
    msg_box2.grid(row=6)
    text_box2 = "Your Move: {m} \nComputer's Move: {c}".format(m=USER, c=CPU)
    msg_box2.insert(END, text_box2)

    #text box that will tell user if they won, lost, or tied against the cpu
    msg_box3 = Text(root, height=1, width=30, state=NORMAL)
    msg_box3.grid(row=7)
    msg_box3.insert(END, text_box3)

    #text box to display messages for certain situations
    #for streaks, every five wins, and more!
    msg_box4 = Text(root, height=1, width=30, state=NORMAL)
    msg_box4.grid(row=8)
    msg_box4.insert(END, text_box4)


# Buttons used
rock_btn = Button(root, height=2, width=10, text='Rock', bg = "cyan", command=rock).grid(row=1)
paper_btn= Button(root, height=2, width=10, text='Paper', bg = "lawn green", command=paper).grid(row=2)
scissor_btn= Button(root, height=2, width=10, text='Scissor', bg = "maroon1", command=scissor).grid(row=3)
stats_btn = Button(root, height=2, width=10, text='Stats', bg = "gold2", command=stats).grid(row =4, pady=50)


root.mainloop()

